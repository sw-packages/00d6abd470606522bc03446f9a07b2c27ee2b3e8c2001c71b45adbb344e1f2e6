<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="uk">
    <dependencies>
        <dependency catalog="qtbase_uk"/>
        <dependency catalog="qtmultimedia_uk"/>
    </dependencies>
</TS>
